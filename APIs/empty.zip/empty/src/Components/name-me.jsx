// ========= IMPORTS ==========
import React from 'react'
//import {useState, useEffect} from 'react'
//import { useParams } from 'react-router'

const {{name-me}} = () => {

// ======== VARIABLES =========


// ======== FUNCTIONS|HANDLERS ==========


// ======== DISPLAY OUT ========
    return (
        <div>
            
        </div>
    )
}

export default {{name-me}}
