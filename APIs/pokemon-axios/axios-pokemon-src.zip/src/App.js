import React from 'react'
// ===== COMPONENTS =====
import Pokemon from './Components/Pokemon';


function App() {
  return (
    <div className="">
      <Pokemon />
    </div>
  );
}

export default App;
