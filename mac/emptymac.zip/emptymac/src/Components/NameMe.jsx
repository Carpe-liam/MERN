// ========= IMPORTS ==========
import React from 'react'
import {
    BrowserRouter,
    Switch,
    Route,
    useHistory
} from 'react-router-dom'
import axios from 'axios'
import {useState, useEffect} from 'react'

const NameMe = () => {

// ======= VARIABLES ========


// ======= FUNCTIONS|HANDLERS ========


// ======= DISPLAY OUT ========
    return (
        <div>
            hello there
        </div>
    )
}

export default NameMe
