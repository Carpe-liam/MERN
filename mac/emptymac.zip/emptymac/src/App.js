import React from 'react'
import {
  BrowserRouter,
  Switch,
  History,
  Route
} from 'react-router-dom'
// ===== IMPORT COMPONENTS =====
import NameMe from './Components/NameMe';

function App() {
  return (
    <div>
      <NameMe />
    </div>
  );
}

export default App;