import React from 'react'
import { Link } from 'react-router-dom'

const ProductList = (props) => { 
    return(
        <div>
            {props.products.map((product, index) => {
                return (
                <p key={index} > 
                    <Link to={product._id}> Title: {product.title} </Link>
                    <hr />
                </p>
                )
            })}
        </div>
    )
}

export default ProductList