import React, { useState, useEffect } from 'react'
import axios from 'axios'
import ProductForm from '../Components/ProductForm'

export default () => {

    return (
        <div>
            <ProductForm />
        </div>
    )
}