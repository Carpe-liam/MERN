const ProductController = require('../controllers/product.controller'); 

module.exports = function(app){
    // CREATE
    app.post('/api/create_product', ProductController.createProduct)
    // READ
    app.get('/api', ProductController.findAllProducts);
    // UPDATE
    // DELETE
}

