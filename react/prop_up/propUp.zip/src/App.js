import React from 'react'
import './App.css';
import Person from './components/NewComponent';

function App() {
  return (
    <div className="App">
      <Person firstName="Alex" lastName="Tyler" age={25} hairColor="Brown"/>
      <Person firstName="Kouvre" lastName="Lux" age={27} hairColor="Black"/>
      <Person firstName="Rylin" lastName="Yina" age={13} hairColor="Blonde"/>
      <Person firstName="Sal" lastName="Nunez" age={32} hairColor="Brown"/>
    </div>
  );
}

export default App;
