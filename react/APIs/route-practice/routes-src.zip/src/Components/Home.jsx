import React from 'react'
// ========= IMPORTS ==========
//import {useState} from 'react'

const Home = () => {

// ======== VARIABLES =========


// ======== FUNCTIONS|HANDLERS ==========


// ======== DISPLAY OUT ========
    return (
        <div className="text-center mt-10 text-4xl">
            <h1>Welcome</h1>
        </div>
    )
}

export default Home
