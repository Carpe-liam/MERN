import React from 'react'
import Pokemon from './Components/Pokemon';
import Test from './Components/Test';

function App() {
  return (
    <div className="">
      <Pokemon />
    </div>
  );
}

export default App;