import './App.css';
import PersonalForm from './Components/PersonalForm';

function App() {
  return (
    <div className="App">
      <PersonalForm />
    </div>
  );
}

export default App;
