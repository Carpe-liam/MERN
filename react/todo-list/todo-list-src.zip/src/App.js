import React from 'react'
import './App.css';

// ==== COMPONENTS ====
import Task from './Components/Task';

function App() {
  return (
    <div className="">
      <Task />
    </div>
  );
}

export default App;
