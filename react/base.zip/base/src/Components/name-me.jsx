import React from 'react'
// ========= IMPORTS ==========
//import {useState} from 'react'

const {{name-me}} = () => {

// ======== VARIABLES =========

// ======== FUNCTIONS ==========

    // +++ HANDLERS +++


// ======== DISPLAY OUT ========
    return (
        <div>
            
        </div>
    )
}

export default {{name-me}}
